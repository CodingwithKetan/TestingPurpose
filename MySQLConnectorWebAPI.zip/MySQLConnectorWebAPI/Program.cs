using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MySqlConnector;
using MySQLConnectorWebAPI.Data;
using MySQLConnectorWebAPI.Services;
using MySQLConnectorWebAPI.Services.Impl;

internal class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddScoped<IProductService, ProductService>();
        builder.Services.AddSwaggerGen();

        var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
        var builderConn = new MySqlConnectionStringBuilder(connectionString);
        var databaseName = builderConn.Database;
        builder.Services.AddSingleton(new DatabaseInitializer(connectionString, databaseName));


        builder.Services.AddControllers();

        var app = builder.Build();
        app.UseSwagger();
        app.UseSwaggerUI();

        var dbInitializer = app.Services.GetRequiredService<DatabaseInitializer>();
        dbInitializer.Initialize();

        app.UseHttpsRedirection();

        app.MapControllers();

        app.Run();
    }
}