using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MySqlConnector;
using MySQLConnectorWebAPI.Data;
using MySQLConnectorWebAPI.Services;
using MySQLConnectorWebAPI.Services.Impl;

internal class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
        builder.Services.AddScoped<IProductService, ProductService>();

// Configure MySQL database connection string
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
            var builderConn = new MySqlConnectionStringBuilder(connectionString);
            var databaseName = builderConn.Database; 
            builder.Services.AddSingleton(new DatabaseInitializer(connectionString, databaseName));


// Configure API controllers
        builder.Services.AddControllers();

        var app = builder.Build();

// Initialize database
        var dbInitializer = app.Services.GetRequiredService<DatabaseInitializer>();
        dbInitializer.Initialize();

// Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseHttpsRedirection();

        app.MapControllers();

        app.Run();
    }
}