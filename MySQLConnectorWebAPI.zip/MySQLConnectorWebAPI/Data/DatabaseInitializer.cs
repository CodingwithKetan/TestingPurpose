using MySqlConnector;

namespace MySQLConnectorWebAPI.Data;

public class DatabaseInitializer
{
    private readonly string _connectionString;
    private readonly string _databaseName;

    public DatabaseInitializer(string connectionString, string databaseName)
    {
        _connectionString = connectionString;
        _databaseName = databaseName;
    }

    public void Initialize()
    {
        using var connection = new MySqlConnection(_connectionString);
        connection.Open();

        // Check if the database exists, if not, create it
        var command = connection.CreateCommand();
        command.CommandText = $"CREATE DATABASE IF NOT EXISTS `{_databaseName}`;";
        command.ExecuteNonQuery();

        // Use the newly created database
        command.CommandText = $"USE `{_databaseName}`;";
        command.ExecuteNonQuery();

        // Create Products table if it doesn't exist
        command.CommandText = @"CREATE TABLE IF NOT EXISTS Products (
                                        Id INT AUTO_INCREMENT PRIMARY KEY,
                                        Name VARCHAR(255) NOT NULL,
                                        Price DECIMAL(10, 2) NOT NULL
                                    );";
        command.ExecuteNonQuery();
    }
}