using Microsoft.AspNetCore.Mvc;
using MySQLConnectorWebAPI.Models;
using MySQLConnectorWebAPI.Services;

namespace MySQLConnectorWebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ProductController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductController(IProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    public ActionResult<List<Product>> Get()
    {
        return Ok(_productService.GetAllProducts());
    }
    
    [HttpPost]
    public IActionResult Post([FromBody] Product product)
    {
        if (product == null)
        {
            return BadRequest("Product is null");
        }

        _productService.AddProduct(product);
        return CreatedAtAction(nameof(Get), new { id = product.Id }, product);
    }
}