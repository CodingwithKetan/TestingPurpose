﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace DotnetFramework462WebAPI.Controllers
{
    public class GeneralController : ApiController
    {
        private static readonly HttpClient _httpClient = new HttpClient();
        
        [HttpGet]
        [Route("joke")]
        public async Task<IHttpActionResult> GetJoke()
        {
            try
            {
                string jokeApiUrl = "https://v2.jokeapi.dev/joke/Any"; // Replace with actual joke API URL
                var response = await _httpClient.GetAsync(jokeApiUrl);

                if (!response.IsSuccessStatusCode)
                {
                    return InternalServerError(new Exception($"Failed to fetch joke. Status: {response.StatusCode}"));
                }

                var joke = await response.Content.ReadAsStringAsync();
                return Ok(joke); // Returns the JSON response from the API
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}