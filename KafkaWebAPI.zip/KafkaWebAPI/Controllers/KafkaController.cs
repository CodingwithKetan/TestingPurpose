using KafkaWebAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace KafkaWebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class KafkaController : ControllerBase
{
    private readonly IKafkaProducerService _producerService;
    private readonly IKafkaConsumerService _consumerService;

    public KafkaController(IKafkaProducerService producerService, IKafkaConsumerService consumerService)
    {
        _producerService = producerService;
        _consumerService = consumerService;
    }

    [HttpPost("produce")]
    public async Task<IActionResult> ProduceMessage([FromBody] string message)
    {
        await _producerService.ProduceAsync(message);
        return Ok("Message sent");
    }

    [HttpGet("consume")]
    public IActionResult ConsumeMessages()
    {
        Task.Run(() => _consumerService.Consume());
        return Ok("Started consuming messages");
    }
}