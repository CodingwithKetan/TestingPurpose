namespace KafkaWebAPI.Services;

public interface IKafkaConsumerService
{
    void Consume();
}