namespace KafkaWebAPI.Services;

public interface IKafkaProducerService
{
    Task ProduceAsync(string message);
}