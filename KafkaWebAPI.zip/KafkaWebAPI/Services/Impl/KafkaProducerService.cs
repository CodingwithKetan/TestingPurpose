using Confluent.Kafka;
using KafkaWebAPI.Models;

namespace KafkaWebAPI.Services.Impl;

public class KafkaProducerService : IKafkaProducerService
{
    private readonly KafkaConfig _config;

    public KafkaProducerService(IConfiguration configuration)
    {
        _config = configuration.GetSection("Kafka").Get<KafkaConfig>();
    }

    public async Task ProduceAsync(string message)
    {
        var config = new ProducerConfig { BootstrapServers = _config?.BootstrapServers };

        using var producer = new ProducerBuilder<Null, string>(config).Build();

        try
        {
            var result = await producer.ProduceAsync(_config?.Topic, new Message<Null, string> { Value = message });
            Console.WriteLine($"Message sent to {result.TopicPartitionOffset}");
        }
        catch (ProduceException<Null, string> ex)
        {
            Console.WriteLine($"An error occurred: {ex.Error.Reason}");
        }
    }
}