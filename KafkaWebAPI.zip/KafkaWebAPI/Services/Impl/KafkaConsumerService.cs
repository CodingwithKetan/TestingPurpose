using Confluent.Kafka;
using KafkaWebAPI.Models;

namespace KafkaWebAPI.Services.Impl;

public class KafkaConsumerService : IKafkaConsumerService
{
    private readonly KafkaConfig _config;

    public KafkaConsumerService(IConfiguration configuration)
    {
        _config = configuration.GetSection("Kafka").Get<KafkaConfig>();
    }

    public void Consume()
    {
        var config = new ConsumerConfig
        {
            BootstrapServers = _config?.BootstrapServers,
            GroupId = _config?.GroupId,
            AutoOffsetReset = AutoOffsetReset.Earliest
        };

        using var consumer = new ConsumerBuilder<Ignore, string>(config).Build();

        consumer.Subscribe(_config?.Topic);

        try
        {
            while (true)
            {
                var result = consumer.Consume();
                Console.WriteLine($"Message: {result.Message.Value}");
            }
        }
        catch (OperationCanceledException)
        {
            consumer.Close();
        }
    }
}