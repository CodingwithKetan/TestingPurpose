using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Quartz;
using Quartz.Spi;
using QuartzWebAPI.Jobs;
using QuartzWebAPI.Services;
using QuartzWebAPI.Services.Impl;
using Swashbuckle.AspNetCore.SwaggerGen;

internal class Program
{
    public static void Main(string[] args)
    {
        var targetFramework = AppDomain.CurrentDomain.SetupInformation.TargetFrameworkName;
        var quartzVersion = typeof(IScheduler).Assembly.GetName().Version;
        Console.WriteLine($"Quartz Version : {quartzVersion.Major}.{quartzVersion.Minor}");
        Console.WriteLine($"{targetFramework}");
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddSwaggerGen();
        // Add services to the container.
        builder.Services.AddControllers();

        // Add Quartz services with conditionally enabled versions
        builder.Services.AddQuartz(q =>
        {
            #if QUARTZ_3_7_0_OR_GREATER
            q.UseMicrosoftDependencyInjectionJobFactory();
            q.UseSimpleTypeLoader();
            #else
            q.UseMicrosoftDependencyInjectionJobFactory();
            #endif
        });

        // Add the Quartz hosted service
        builder.Services.AddQuartzHostedService(q => q.WaitForJobsToComplete = true);

        // Add custom services
        builder.Services.AddScoped<IJobService, JobService>();

        var app = builder.Build();
        
        app.UseSwagger();
        app.UseSwaggerUI();

        // Configure the HTTP request pipeline.
        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}

