using Microsoft.AspNetCore.Mvc;
using QuartzWebAPI.Services;

namespace QuartzWebAPI
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobController : ControllerBase
    {
        private readonly IJobService _jobService;

        public JobController(IJobService jobService)
        {
            _jobService = jobService;
        }

        [HttpPost("start")]
        public IActionResult StartJob()
        {
            _jobService.StartJob();
            return Ok("Job started.");
        }

        [HttpPost("stop")]
        public IActionResult StopJob()
        {
            _jobService.StopJob();
            return Ok("Job stopped.");
        }
    }
}