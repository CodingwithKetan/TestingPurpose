using System;
using System.Threading.Tasks;
using Quartz;

namespace QuartzWebAPI.Jobs
{
    public class TestJob : IJob
    {
        public Task Execute(IJobExecutionContext context)
        {
            // Execute your task logic here
            Console.WriteLine($"Job {context.JobDetail.Key} executed at {DateTime.Now}");
            return Task.CompletedTask;
        }
    }
}