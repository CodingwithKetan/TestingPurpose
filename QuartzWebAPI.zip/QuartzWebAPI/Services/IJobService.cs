namespace QuartzWebAPI.Services
{
    public interface IJobService
    {
        void StartJob();
        void StopJob();
    }
}