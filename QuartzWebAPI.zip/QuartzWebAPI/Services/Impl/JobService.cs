using System;
using Quartz;
using QuartzWebAPI.Jobs;

namespace QuartzWebAPI.Services.Impl
{
    public class JobService : IJobService
    {
        private readonly ISchedulerFactory _schedulerFactory;
        private IScheduler _scheduler;

        public JobService(ISchedulerFactory schedulerFactory)
        {
            _schedulerFactory = schedulerFactory;
            _scheduler = _schedulerFactory.GetScheduler().Result;
        }

        public void StartJob()
        {
            Console.WriteLine("Job started, I will executing for every 2 seconds");
            var job = JobBuilder.Create<TestJob>()
                .WithIdentity("TestJob", "Group1")
                .Build();

            var trigger = TriggerBuilder.Create()
                .WithIdentity("TestTrigger", "Group1")
                .StartNow()
                .WithSimpleSchedule(x => x
                    .WithIntervalInSeconds(2)  // Set interval to 2 seconds
                    .RepeatForever())           // Ensure it repeats indefinitely
                .Build();

            _scheduler.ScheduleJob(job, trigger);

        }

        public void StopJob()
        {
            Console.WriteLine("All the Jobs will stopped");
            _scheduler.Clear();
        }
    }
}